This folder contains simulation results for testing the false positive rate and power of my_ldhot.

Files named flat-* represent 25 simulations conducted with a constant rate of rho = 0.44 / kb.

Files named hot-* represent 25 simulations conducted with a background rate of 0.02 / kb, and eight hotspots. 
The eight hotspots are centered at positions 75, 125, 175, 225, 275, 325, 375, and 425, and have a 95% width of 2kb.
The magnitudes of the hotspots are rho = 1, 2, 4, 8, 16, 32, 64, and 128, respectively.

*.seq files contain the LDhat format haplotypes.
*.loc files contain the LDhat positions.
*.res files contain the LDhat rate estimates.
*.hotspots.txt contain the output of my_ldhot.
*.log contain the my_ldhot log files.

The subfolder simulation_results_sequenceLDhot contains the same simulations in sequenceLDhot file. Both the input 
and result output is included.

March 8th 2014

