function calc_simulation_results

hotspot_kb_pos = [75 125 175 225 275 325 375 425];     % kb
hotspots(:,1) = hotspot_kb_pos - 1; % LHS boundary
hotspots(:,2) = hotspot_kb_pos + 1; % RHS boundary

% Flat simulations
disp('Flat N=20 LDhot')
folder = '../flat_n20/';
[N_false, power] = calc_LDhot_results(folder, []);
disp(['   N false = ' num2str(N_false)]);
disp(' ');

disp('Flat N=20 sequenceLDhot')
folder = '../flat_n20_sequenceLDhot/';
[N_false, power] = calc_sequenceLDhot_results(folder, []);
disp(['   N false = ' num2str(N_false)]);
disp(' ');

disp('Eight hotspots N=20 LDhot')
folder = '../hot_n20/';
[N_false, power] = calc_LDhot_results(folder, hotspots);
disp(['   N false = ' num2str(N_false)]);
disp(['   power = ' num2str(power')]);
disp(' ');

disp('Eight hotspots N=20 sequenceLDhot')
folder = '../hot_n20_sequenceLDhot/';
[N_false, power] = calc_sequenceLDhot_results(folder, hotspots);
disp(['   N false = ' num2str(N_false)]);
disp(['   power = ' num2str(power')]);
disp(' ');


disp('Eight hotspots N=50 LDhot')
folder = '../hot_n50/';
[N_false, power] = calc_LDhot_results(folder, hotspots);
disp(['   N false = ' num2str(N_false)]);
disp(['   power = ' num2str(power')]);
disp(' ');

disp('Eight hotspots N=50 sequenceLDhot')
folder = '../hot_n50_sequenceLDhot/';
[N_false, power] = calc_sequenceLDhot_results(folder, hotspots);
disp(['   N false = ' num2str(N_false)]);
disp(['   power = ' num2str(power')]);
disp(' ');

