function [N_false, power] = calc_LDhot_results(folder, hotspots)

if (nargin < 1)
    folder = '../hot_n50/';
end

hot_files = dir([folder '*.hot_summary.txt']);

N_false = 0;
N_hotspots = size(hotspots, 1);
N_true = zeros(N_hotspots, 1);

for i=1:length(hot_files)
    try
        data = dlmread([folder hot_files(i).name], '\t', 1, 0);
        hotStart = data(:, 1);
        hotEnd = data(:, 2);
        % Find true positives
        for j=1:N_hotspots
            [start_result, end_result, idx] = hasOverlap(hotStart, hotEnd, hotspots(j,1), hotspots(j,1));
            if (~isempty(idx))
                N_true(j) = N_true(j) + 1;
            end
        end
        % Find false positives
        if (N_hotspots > 0)
            for j=1:length(hotStart)
                [start_result, end_result, idx] = hasOverlap(hotStart(j), hotEnd(j), hotspots(:,1), hotspots(:,2));
                if (isempty(idx))
                    N_false = N_false + 1;
                end
            end
        else
            N_false = N_false + length(hotStart);
        end
    catch ME
        %disp([hot_files(i).name ' failed']);
    end
end

power = N_true / length(hot_files);

