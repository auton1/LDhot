function [start_result, end_result, idx] = hasOverlap(start1, end1, start2, end2)
% Compares two sets of intervals, and returns the subset of the 
% first set that overlaps with the second set.
%
% Usage: [start_result, end_result, idx] = hasOverlap(start1, end1, start2, end2);
%
% Example:
%   start1 = [1; 50; 200; 90; 190; 140; 90; 220];
%   end1 = [2; 100; 250; 110; 210; 160; 210; 222];
%   start2 = [100];
%   end2 = [200];
%   [start_result, end_result, idx] = hasOverlap(start1, end1, start2, end2);
% 

keep = zeros(size(start1));
for i=1:length(start1)
    tf = any((start1(i) >= start2) & (start1(i) < end2)) ...
            | any((end1(i) > start2) & (end1(i) <= end2)) ...
            | any((start1(i) <= start2) & (end1(i) >= end2));
    
    if (tf == 1)
        keep(i) = 1;
    end
end
idx = find(keep);
start_result = start1(idx);
end_result = end1(idx);