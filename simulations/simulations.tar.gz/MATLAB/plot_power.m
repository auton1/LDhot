function plot_power

figure;
set(gcf, 'Position', [500 926 1539 420]);

% Define hotspot positions
Ne = 10000;
hotspot_kb_pos = [75 125 175 225 275 325 375 425];   % kb
hotspot_kb_pos_lhs = hotspot_kb_pos - 1;             % Boundaries
hotspot_kb_pos_rhs = hotspot_kb_pos + 1;
hotspot_peak_rates = [1 2 4 8 16 32 64 128];         % cM / Mb
hotspot_95prct_width = 2*ones(size(hotspot_kb_pos)); % kb
hotspot_sigma = hotspot_95prct_width / 4;
hotspot_mag = hotspot_peak_rates .* hotspot_sigma/1000 * sqrt(2*pi);
hotspot_mag = 4*Ne*hotspot_mag / 100;                % 4Ner magnitude

% Main plot
subplot(1,3,1:2)
% Load simulated rates
map = dlmread('eight_hotspots.500kb.txt', '\t', 1, 0);
map(:,1) = map(:,1) / max(map(:,1)) * 500;
rate = diff(map(:,2)) ./ diff(map(:,1));
stairs(map(1:end-1, 1), rate, 'k', 'LineWidth', 1);
hold on
% Plot hotspot positions
for j=1:length(hotspot_kb_pos)
    plot([hotspot_kb_pos(j) hotspot_kb_pos(j)], [0.01 10^4], ':k');
end
xlabel('Position (kb)');
ylabel('4N_er / kb                          ');

set(gca, 'YScale', 'log');

% Clean up tick labels
YTick = [0.01 0.1 1 10 100 10^2.6 10^3.6];
YTickLabels = cellstr(num2str(YTick(:), '%g'));
YTickLabels{end-1} = 'n = 20';
YTickLabels{end} = 'n = 50';
set(gca, 'YTickLabel', YTickLabels, 'YTick', YTick);
set(gca, 'YMinorTick', 'off')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot hotspot calls for n = 20 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
folder1 = '../hot_n20/';
hot_files1 = dir([folder1 'hot*hot_summary.txt']);
folder2 = '../hot_n20_sequenceLDhot/';

ymin = 10^2.15;
ymax = 10^3.05;
y1 = logspace(log10(ymin), log10(ymax), length(hot_files1));
y2 = logspace(log10(ymin)-0.01, log10(ymax)-0.01, length(hot_files1));
for i=1:length(hot_files1)
    file = hot_files1(i).name;
    a=textscan(file, '%s %s', 'delimiter', '-');
    b=textscan(char(a{2}), '%n %*s %*s', 'delimiter', '.');
    b = b{1};
    
    file1 = [folder1 file];
    file2 = [folder2 'hotres' num2str(b)];
    
    data1 = dlmread(file1, '\t', 1, 0); % LDhot calls
	hotStart1 = data1(:, 1);
    hotEnd1 = data1(:, 2);
        
    data2 = dlmread(file2, '\t', 1, 0); % Sequence LDhot calls
	hotStart2 = data2(:, 4)/1000;
    hotEnd2 = data2(:, 5)/1000;
    
    for j=1:length(hotStart1)
        [~, ~, idx] = hasOverlap(hotStart1(j), hotEnd1(j), hotspot_kb_pos_lhs, hotspot_kb_pos_rhs);
        if (~isempty(idx))
            plot([hotStart1(j) hotEnd1(j)], [y1(i) y1(i)], '-r');
        else
            plot([hotStart1(j) hotEnd1(j)], [y1(i) y1(i)], '-r', 'LineWidth', 2);
        end
    end
    
    for j=1:length(hotStart2)
        [~, ~, idx] = hasOverlap(hotStart2(j), hotEnd2(j), hotspot_kb_pos_lhs, hotspot_kb_pos_rhs);
        if (~isempty(idx))
            plot([hotStart2(j) hotEnd2(j)], [y2(i) y2(i)], '-b');
        else
            plot([hotStart2(j) hotEnd2(j)], [y2(i) y2(i)], '-b', 'LineWidth', 2);
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot hotspot calls for n = 50 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

folder1 = '../hot_n50/';
hot_files1 = dir([folder1 'hot*hot_summary.txt']);
folder2 = '../hot_n50_sequenceLDhot/';

ymin = 10^3.15;
ymax = 10^3.95;
y1 = logspace(log10(ymin), log10(ymax), length(hot_files1));
y2 = logspace(log10(ymin)-0.01, log10(ymax)-0.01, length(hot_files1));
for i=1:length(hot_files1)
    file = hot_files1(i).name;
    a=textscan(file, '%s %s', 'delimiter', '-');
    b=textscan(char(a{2}), '%n %*s %*s', 'delimiter', '.');
    b = b{1};
    
    file1 = [folder1 file];
    file2 = [folder2 'hotres' num2str(b)];
    
    data1 = dlmread(file1, '\t', 1, 0);
	hotStart1 = data1(:, 1);
    hotEnd1 = data1(:, 2);
        
    data2 = dlmread(file2, '\t', 1, 0);
	hotStart2 = data2(:, 4)/1000;
    hotEnd2 = data2(:, 5)/1000;
    
    for j=1:length(hotStart1)
        [~, ~, idx] = hasOverlap(hotStart1(j), hotEnd1(j), hotspot_kb_pos_lhs, hotspot_kb_pos_rhs);
        if (~isempty(idx))
            plot([hotStart1(j) hotEnd1(j)], [y1(i) y1(i)], '-r');
        else
            plot([hotStart1(j) hotEnd1(j)], [y1(i) y1(i)], '-r', 'LineWidth', 2);
        end
    end
    
    for j=1:length(hotStart2)
        [~, ~, idx] = hasOverlap(hotStart2(j), hotEnd2(j), hotspot_kb_pos_lhs, hotspot_kb_pos_rhs);
        if (~isempty(idx))
            plot([hotStart2(j) hotEnd2(j)], [y2(i) y2(i)], '-b');
        else
            plot([hotStart2(j) hotEnd2(j)], [y2(i) y2(i)], '-b', 'LineWidth', 2);
        end
    end
end

plot([0 500], [10^2.1 10^2.1], '-k');
plot([0 500], [10^3.1 10^3.1], '-k');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate power for n=50 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

folder1 = '../hot_n50/';
hot_files1 = dir([folder1 'hot*hot_summary.txt']);
folder2 = '../hot_n50_sequenceLDhot/';
hot_files2 = dir([folder2 'hotres*']);

N_true1 = zeros(size(hotspot_mag));
N_true2 = zeros(size(hotspot_mag));
for i=1:length(hot_files1)
    file = hot_files1(i).name;
    a=textscan(file, '%s %s', 'delimiter', '-');
    b=textscan(char(a{2}), '%n %*s %*s', 'delimiter', '.');
    b = b{1};
    
    file1 = [folder1 file];
    file2 = [folder2 'hotres' num2str(b)];
    
    data1 = dlmread(file1, '\t', 1, 0);
	hotStart1 = data1(:, 1);
    hotEnd1 = data1(:, 2);
        
    data2 = dlmread(file2, '\t', 1, 0);
	hotStart2 = data2(:, 4)/1000;
    hotEnd2 = data2(:, 5)/1000;
    
    for j=1:length(hotspot_kb_pos)
        [start_result, end_result, idx] = hasOverlap(hotStart1, hotEnd1, hotspot_kb_pos_lhs(j), hotspot_kb_pos_rhs(j));
        if (~isempty(idx))
            N_true1(j) = N_true1(j) + 1;
        end
    end
    
    for j=1:length(hotspot_kb_pos)
        [start_result, end_result, idx] = hasOverlap(hotStart2, hotEnd2, hotspot_kb_pos_lhs(j), hotspot_kb_pos_rhs(j));
        if (~isempty(idx))
            N_true2(j) = N_true2(j) + 1;
        end
    end
    
end

power_LDhot_n50 = N_true1/length(hot_files1);
power_seqLDhot_n50 = N_true2/length(hot_files2);
p_adj_LDhot_n_50 = (N_true1+2)/(length(hot_files1)+4);
p_adj_seqLDhot_n_50 = (N_true2+2)/(length(hot_files2)+4);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate power for n=20 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

folder1 = '../hot_n20/';
hot_files1 = dir([folder1 'hot*hot_summary.txt']);
folder2 = '../hot_n20_sequenceLDhot/';
hot_files2 = dir([folder2 'hotres*']);

N_true1 = zeros(size(hotspot_mag));
N_true2 = zeros(size(hotspot_mag));
for i=1:length(hot_files1)
    file = hot_files1(i).name;
    a=textscan(file, '%s %s', 'delimiter', '-');
    b=textscan(char(a{2}), '%n %*s %*s', 'delimiter', '.');
    b = b{1};
    
    file1 = [folder1 file];
    file2 = [folder2 'hotres' num2str(b)];
    
    data1 = dlmread(file1, '\t', 1, 0);
	hotStart1 = data1(:, 1);
    hotEnd1 = data1(:, 2);
        
    data2 = dlmread(file2, '\t', 1, 0);
	hotStart2 = data2(:, 4)/1000;
    hotEnd2 = data2(:, 5)/1000;
    
    for j=1:length(hotspot_kb_pos)
        [start_result, end_result, idx] = hasOverlap(hotStart1, hotEnd1, hotspot_kb_pos_lhs(j), hotspot_kb_pos_rhs(j));
        if (~isempty(idx))
            N_true1(j) = N_true1(j) + 1;
        end
    end
    
    for j=1:length(hotspot_kb_pos)
        [start_result, end_result, idx] = hasOverlap(hotStart2, hotEnd2, hotspot_kb_pos_lhs(j), hotspot_kb_pos_rhs(j));
        if (~isempty(idx))
            N_true2(j) = N_true2(j) + 1;
        end
    end
end

power_LDhot_n20 = N_true1/length(hot_files1);
power_seqLDhot_n20 = N_true2/length(hot_files2);
p_adj_LDhot_n_20 = (N_true1+2)/(length(hot_files1)+4);
p_adj_seqLDhot_n_20 = (N_true2+2)/(length(hot_files2)+4);


% Plot power curve

subplot(1,3,3);
h(1)=plot(hotspot_mag, power_LDhot_n20, '-or','MarkerFaceColor','auto');
%h(1) = errorbar(hotspot_mag, power_LDhot_n20, sqrt(p_adj_LDhot_n_20 .* (1-p_adj_LDhot_n_20) / length(hot_files1)), '-or', 'MarkerFaceColor','auto');
hold on
h(2)=plot(hotspot_mag, power_LDhot_n50, '-or', 'LineWidth', 2,'MarkerFaceColor','auto');
%h(2)=errorbar(hotspot_mag, power_LDhot_n50, sqrt(p_adj_LDhot_n_50 .* (1-p_adj_LDhot_n_50) / length(hot_files1)), '-or', 'LineWidth', 2,'MarkerFaceColor','auto');
plot(hotspot_mag, power_seqLDhot_n20, '-ob','MarkerFaceColor','auto');
%errorbar(hotspot_mag, power_seqLDhot_n20, sqrt(p_adj_seqLDhot_n_20 .* (1-p_adj_seqLDhot_n_20) / length(hot_files1)), '-ob', 'MarkerFaceColor','auto');
plot(hotspot_mag, power_seqLDhot_n50, '-ob', 'LineWidth', 2,'MarkerFaceColor','auto');
%errorbar(hotspot_mag, power_seqLDhot_n50, sqrt(p_adj_seqLDhot_n_50 .* (1-p_adj_seqLDhot_n_50) / length(hot_files1)), '-ob', 'LineWidth', 2,'MarkerFaceColor','auto');
set(gca, 'XScale', 'log');
ylim([0 1.01])
xlim([0.4 100])
XTick = get(gca, 'XTick');
XTickLabels = cellstr(num2str(round(XTick(:)), '%d'));
set(gca, 'XTickLabel', XTickLabels);
legend('LDhot', 'sequenceLDhot', 'Location', 'NorthWest');
xlabel('Hotspot magnitude (4N_er)')
ylabel('Power');
axis square
legend('LDhot n=20', 'LDhot n=50', 'sequenceLDhot n=20', 'sequenceLDhot n=50', 'Location', 'NorthWest');
legend('boxoff');
uistack(h,'top')

set(findall(gcf,'type','text'),'fontSize',12,'fontWeight','bold')