plot_power.m is a Matlab script to display a pretty plot of the hotspot results.

calc_simulation_results.m is a MATLAB script that displays the power and false positive estimates.